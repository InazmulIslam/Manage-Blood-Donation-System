<?php
$dbServerName = "localhost";
$dbUser       = "root";
$dbPass       = "";
$db           = "rokto_db";
$conn = mysqli_connect($dbServerName, $dbUser, $dbPass, $db);
